#include "header.h"
void foo_1() { printf("Doing something %d\n", 1); }
