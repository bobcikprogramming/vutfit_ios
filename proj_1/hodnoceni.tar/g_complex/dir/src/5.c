#include "header.h"
void foo_5() { printf("Doing something %d\n", 5); }
